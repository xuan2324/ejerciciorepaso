'''Crear estas clases
Define los atributos, métodos, constructores... que consideres
necesarios.

cursos:id,nombre, creditos, añosdeestudio
alumno:id, nombre, email
matricula:idmatricula, fechamatricula, idalumno, idcurso

Necesitamos.
mostrar la ficha del curso
mostrar la ficha de alumno
alumno1 se matricula en un curso
alumno2 se matricula en dos cursos
mostrar los datos de matrículo
reto*:método que muestra las mátriculas realizadas en mi centro
'''

from datetime import datetime

class Curso:
    def __init__(self, id, nombre, creditos, años_de_estudio):
        self.id = id
        self.nombre = nombre
        self.creditos = creditos
        self.años_de_estudio = años_de_estudio

    def mostrar_ficha(self):
        print("ID:", self.id)
        print("Nombre:", self.nombre)
        print("Créditos:", self.creditos)
        print("Años de estudio:", self.años_de_estudio)


class Alumno:
    def __init__(self, id, nombre, email):
        self.id = id
        self.nombre = nombre
        self.email = email

    def mostrar_ficha(self):
        print("ID:", self.id)
        print("Nombre:", self.nombre)
        print("Email:", self.email)


class Matricula:
    def __init__(self, id_matricula, id_alumno):
        self.id_matricula = id_matricula
        self.fecha_matricula = datetime.now()
        self.id_alumno = id_alumno
        self.id_cursos = []

    def matricular_en_curso(self, id_curso):
        self.id_cursos.append(id_curso)

    def mostrar_datos(self):
        print("ID Matrícula:", self.id_matricula)
        print("Fecha Matrícula:", self.fecha_matricula)
        print("ID Alumno:", self.id_alumno)
        print("ID Cursos Matriculados:", self.id_cursos)


class CentroEducativo:
    def __init__(self):
        self.matriculas = []

    def realizar_matricula(self, id_matricula, id_alumno):
        nueva_matricula = Matricula(id_matricula, id_alumno)
        self.matriculas.append(nueva_matricula)

    def mostrar_matriculas(self):
        for matricula in self.matriculas:
            matricula.mostrar_datos()
            print("--------------")


if __name__ == "__main__":
    curso1 = Curso("curso1", "Programación Python", 4, 2)
    alumno1 = Alumno("alumno1", "Juan Perez", "juan@example.com")
    alumno2 = Alumno("alumno2", "Maria Garcia", "maria@example.com")

    curso1.mostrar_ficha()
    alumno1.mostrar_ficha()

    matricula1 = Matricula(1, alumno1.id)
    matricula1.matricular_en_curso(curso1.id)

    matricula2 = Matricula(2, alumno2.id)
    matricula2.matricular_en_curso(curso1.id)
    matricula2.matricular_en_curso(2)  # Alumno2 se matricula en otro curso

    matricula1.mostrar_datos()
    matricula2.mostrar_datos()

    centro = CentroEducativo()
    centro.realizar_matricula(3, alumno1.id)
    centro.realizar_matricula(4, alumno2.id)

    centro.mostrar_matriculas()
